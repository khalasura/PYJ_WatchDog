﻿using System.Windows.Controls;

namespace PYJ_WatchDog.Views
{
    /// <summary>
    /// Interaction logic for TaskDialog
    /// </summary>
    public partial class TaskDialog : UserControl
    {
        public TaskDialog()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace PYJ_WatchDog.Views
{
    /// <summary>
    /// Interaction logic for SettingDialog
    /// </summary>
    public partial class SettingDialog : UserControl
    {
        public SettingDialog()
        {
            InitializeComponent();
        }
    }
}

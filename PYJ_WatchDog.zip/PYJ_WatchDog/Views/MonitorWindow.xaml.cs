﻿using MahApps.Metro.Controls;
using PYJ_WatchDog.Models;
using System.Windows;
using System.Windows.Controls;

namespace PYJ_WatchDog.Views
{
    /// <summary>
    /// Interaction logic for MonitorWindow
    /// </summary>
    public partial class MonitorWindow : UserControl
    {
        public MonitorWindow()
        {
            InitializeComponent();
        }
    }
}

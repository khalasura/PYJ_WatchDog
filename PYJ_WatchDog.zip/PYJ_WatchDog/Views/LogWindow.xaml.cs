﻿using System.Windows.Controls;

namespace PYJ_WatchDog.Views
{
    /// <summary>
    /// Interaction logic for LogWindow
    /// </summary>
    public partial class LogWindow : UserControl
    {
        public LogWindow()
        {
            InitializeComponent();
        }
    }
}

﻿using Prism.Events;
using PYJ_WatchDog.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PYJ_WatchDog.Events
{
    public class SettingEvent : PubSubEvent<Settings> { }

}
